<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['name']        = __( 'HT Event Tickets', 'plan-up' );
$manifest['description'] = __( "This extension provides management system for event registration", 'plan-up' );
$manifest['version'] = '1.0.1';
$manifest['display'] = true;
$manifest['standalone'] = true;
$manifest['thumbnail'] = 'fa fa-ticket';
$manifest['github_update'] = '';
